/* ==========================================================================
   The Music Factory — site behavior
   You should not need to edit this file to update content.
   Events live in data/events.js and music lives in data/music.js.
   ========================================================================== */
(function () {
  "use strict";

  /* ---------------------------------------------------------- utilities -- */

  var MONTHS = ["January","February","March","April","May","June",
                "July","August","September","October","November","December"];
  var DAYS = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];

  // "2026-12-10" -> a Date in the visitor's own time zone (not UTC).
  function parseDate(str) {
    var p = String(str).split("-");
    return new Date(Number(p[0]), Number(p[1]) - 1, Number(p[2]));
  }

  function startOfToday() {
    var n = new Date();
    return new Date(n.getFullYear(), n.getMonth(), n.getDate());
  }

  function el(tag, className, text) {
    var node = document.createElement(tag);
    if (className) node.className = className;
    if (text != null) node.textContent = text;
    return node;
  }

  function gradeLabel(grades) {
    if (!grades || !grades.length) return "";
    if (grades.length === 1 && String(grades[0]).toLowerCase() === "all") return "All grades";
    return grades.map(function (g) { return g === "K" ? "K" : "Grade " + g; }).join(", ");
  }

  function matchesGrade(event, grade) {
    if (grade === "all") return true;
    var g = event.grades || [];
    if (g.some(function (x) { return String(x).toLowerCase() === "all"; })) return true;
    return g.some(function (x) { return String(x) === grade; });
  }

  var TYPE_COLOR = {
    "Concert": "var(--red)",
    "Rehearsal": "var(--blue)",
    "Performance": "var(--purple)",
    "Trip": "var(--green)",
    "Special Event": "var(--orange)"
  };

  /* ------------------------------------------------------- mobile nav -- */

  function initNav() {
    var toggle = document.querySelector(".nav-toggle");
    var nav = document.getElementById("primary-nav");
    if (!toggle || !nav) return;

    toggle.addEventListener("click", function () {
      var open = nav.classList.toggle("is-open");
      toggle.setAttribute("aria-expanded", open ? "true" : "false");
      toggle.querySelector(".nav-toggle__label").textContent = open ? "Close" : "Menu";
    });
  }

  /* ---------------------------------------------------- event rendering -- */

  function buildEvent(ev) {
    var date = parseDate(ev.date);
    var isPast = date < startOfToday();

    var li = el("li", "event" + (isPast ? " is-past" : ""));
    li.style.setProperty("--c", TYPE_COLOR[ev.type] || "var(--navy)");

    // date block
    var d = el("div", "event__date");
    d.appendChild(el("span", "event__month", MONTHS[date.getMonth()].slice(0, 3)));
    d.appendChild(el("span", "event__day", String(date.getDate())));
    d.appendChild(el("span", "event__year", String(date.getFullYear())));
    li.appendChild(d);

    // body
    var body = el("div", "event__body");

    var h = el("h3", "event__title");
    h.appendChild(document.createTextNode(ev.title + " "));
    if (isPast) {
      h.appendChild(el("span", "tag tag--past", "Past"));
    } else if (ev.required) {
      h.appendChild(el("span", "tag tag--required", "Required"));
    } else {
      h.appendChild(el("span", "tag tag--optional", "Optional"));
    }
    body.appendChild(h);

    var meta = el("ul", "event__meta");
    function addMeta(label, value) {
      if (!value) return;
      var item = el("li");
      item.appendChild(el("strong", null, label + ": "));
      item.appendChild(document.createTextNode(value));
      meta.appendChild(item);
    }
    addMeta("Day", DAYS[date.getDay()]);
    addMeta("Time", ev.time);
    addMeta("Students arrive", ev.callTime);
    addMeta("Where", ev.location);
    addMeta("Who", gradeLabel(ev.grades));
    addMeta("Wear", ev.attire);
    body.appendChild(meta);

    if (ev.notes) body.appendChild(el("p", "event__note", ev.notes));

    li.appendChild(body);
    return li;
  }

  /* --------------------------------------------------- home: next events -- */

  function initUpcoming() {
    var host = document.getElementById("upcoming-events");
    if (!host || !window.MF_EVENTS) return;

    var today = startOfToday();
    var upcoming = window.MF_EVENTS
      .filter(function (ev) { return parseDate(ev.date) >= today; })
      .sort(function (a, b) { return parseDate(a.date) - parseDate(b.date); })
      .slice(0, 3);

    if (!upcoming.length) {
      host.appendChild(el("p", "empty-note",
        "No upcoming events are posted right now. Check back soon!"));
      return;
    }

    var list = el("ul", "event-list");
    upcoming.forEach(function (ev) { list.appendChild(buildEvent(ev)); });
    host.appendChild(list);
  }

  /* ------------------------------------------------ calendar page render -- */

  function initCalendar() {
    var host = document.getElementById("calendar-list");
    if (!host || !window.MF_EVENTS) return;

    var gradeSel = document.getElementById("filter-grade");
    var typeSel = document.getElementById("filter-type");
    var whenSel = document.getElementById("filter-when");
    var count = document.getElementById("filter-count");

    // Fill the "type" menu from whatever types actually exist in the data.
    if (typeSel) {
      var types = [];
      window.MF_EVENTS.forEach(function (ev) {
        if (ev.type && types.indexOf(ev.type) === -1) types.push(ev.type);
      });
      types.sort().forEach(function (t) {
        var o = el("option", null, t);
        o.value = t;
        typeSel.appendChild(o);
      });
    }

    function render() {
      var grade = gradeSel ? gradeSel.value : "all";
      var type = typeSel ? typeSel.value : "all";
      var when = whenSel ? whenSel.value : "upcoming";
      var today = startOfToday();

      var rows = window.MF_EVENTS
        .filter(function (ev) {
          if (!matchesGrade(ev, grade)) return false;
          if (type !== "all" && ev.type !== type) return false;
          var past = parseDate(ev.date) < today;
          if (when === "upcoming" && past) return false;
          if (when === "past" && !past) return false;
          return true;
        })
        .sort(function (a, b) {
          var diff = parseDate(a.date) - parseDate(b.date);
          return when === "past" ? -diff : diff;
        });

      host.innerHTML = "";
      if (!rows.length) {
        host.appendChild(el("p", "empty-note",
          "Nothing matches those choices yet. Try setting the menus back to “All”."));
      } else {
        var list = el("ul", "event-list");
        rows.forEach(function (ev) { list.appendChild(buildEvent(ev)); });
        host.appendChild(list);
      }

      if (count) {
        count.textContent = rows.length === 1 ? "1 event" : rows.length + " events";
      }
    }

    [gradeSel, typeSel, whenSel].forEach(function (s) {
      if (s) s.addEventListener("change", render);
    });
    render();
  }

  /* --------------------------------------------------- music page render -- */

  var RES_ICON = {
    lyrics: "📄",
    recording: "🎧",
    track: "🎹",
    choreography: "💃",
    video: "▶️",
    pdf: "📄",
    link: "🔗"
  };

  function buildSong(song) {
    var wrap = el("div", "song");
    wrap.appendChild(el("h4", null, song.title));
    if (song.forEvent) wrap.appendChild(el("p", "song__for", "For: " + song.forEvent));

    var res = song.resources || [];
    if (!res.length) {
      wrap.appendChild(el("p", "song__for", "Materials coming soon."));
      return wrap;
    }

    var ul = el("ul", "resources");
    res.forEach(function (r) {
      var li = el("li");
      var a = el("a");
      a.href = r.url || "#";
      if (/^https?:/i.test(a.getAttribute("href"))) {
        a.target = "_blank";
        a.rel = "noopener";
      }
      var icon = el("span", "res-icon", RES_ICON[r.kind] || RES_ICON.link);
      icon.setAttribute("aria-hidden", "true");
      a.appendChild(icon);
      a.appendChild(document.createTextNode(r.label || "Open"));
      li.appendChild(a);
      ul.appendChild(li);
    });
    wrap.appendChild(ul);
    return wrap;
  }

  function buildModule(mod, index) {
    var section = el("section", "module");
    section.id = mod.id || "module-" + index;

    var panelId = section.id + "-panel";
    var btnId = section.id + "-button";

    var btn = el("button", "module__toggle");
    btn.type = "button";
    btn.id = btnId;
    btn.setAttribute("aria-expanded", "false");
    btn.setAttribute("aria-controls", panelId);
    btn.style.setProperty("--c", mod.color || "var(--blue)");

    var badge = el("div", "module__badge");
    badge.style.setProperty("--c", mod.color || "var(--blue)");
    badge.setAttribute("aria-hidden", "true");
    if (String(mod.badge || "").length > 2) badge.style.fontSize = ".8rem";
    badge.appendChild(document.createTextNode(mod.badge || ""));
    btn.appendChild(badge);

    var text = el("div");
    text.appendChild(el("h3", "module__heading", mod.title));
    if (mod.subtitle) text.appendChild(el("p", "module__sub", mod.subtitle));
    btn.appendChild(text);

    var chev = el("span", "module__chev", "▾");
    chev.setAttribute("aria-hidden", "true");
    btn.appendChild(chev);

    var panel = el("div", "module__panel");
    panel.id = panelId;
    panel.setAttribute("role", "region");
    panel.setAttribute("aria-labelledby", btnId);
    panel.hidden = true;

    if (mod.intro) panel.appendChild(el("p", null, mod.intro));

    var songs = mod.songs || [];
    if (!songs.length) {
      panel.appendChild(el("p", "empty-note",
        "Materials for this grade will be posted soon. Check back after our next class!"));
    } else {
      songs.forEach(function (s) { panel.appendChild(buildSong(s)); });
    }

    btn.addEventListener("click", function () {
      var open = btn.getAttribute("aria-expanded") === "true";
      btn.setAttribute("aria-expanded", open ? "false" : "true");
      panel.hidden = open;
      if (!open && history.replaceState) {
        history.replaceState(null, "", "#" + section.id);
      }
    });

    section.appendChild(btn);
    section.appendChild(panel);
    return section;
  }

  function initMusic() {
    var host = document.getElementById("music-modules");
    if (!host || !window.MF_MUSIC) return;

    host.innerHTML = "";
    window.MF_MUSIC.forEach(function (mod, i) {
      host.appendChild(buildModule(mod, i));
    });

    // Buttons that open a specific grade, e.g. <a href="#grade-3">
    function openFromHash() {
      var id = (location.hash || "").replace("#", "");
      if (!id) return;
      var section = document.getElementById(id);
      if (!section || !section.classList.contains("module")) return;
      var btn = section.querySelector(".module__toggle");
      var panel = section.querySelector(".module__panel");
      if (btn && panel && btn.getAttribute("aria-expanded") !== "true") {
        btn.setAttribute("aria-expanded", "true");
        panel.hidden = false;
      }
      section.scrollIntoView({ block: "start" });
    }
    openFromHash();
    window.addEventListener("hashchange", openFromHash);

    var expandAll = document.getElementById("expand-all");
    if (expandAll) {
      expandAll.addEventListener("click", function () {
        var opening = expandAll.getAttribute("data-state") !== "open";
        host.querySelectorAll(".module").forEach(function (section) {
          section.querySelector(".module__toggle").setAttribute("aria-expanded", opening ? "true" : "false");
          section.querySelector(".module__panel").hidden = !opening;
        });
        expandAll.setAttribute("data-state", opening ? "open" : "closed");
        expandAll.textContent = opening ? "Collapse all grades" : "Open all grades";
      });
    }
  }

  /* --------------------------------------------------------------- init -- */

  function init() {
    initNav();
    initUpcoming();
    initCalendar();
    initMusic();

    var year = document.getElementById("year");
    if (year) year.textContent = new Date().getFullYear();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
