/* ==========================================================================
   THE MUSIC FACTORY — EVENT CALENDAR DATA
   --------------------------------------------------------------------------
   This is the ONLY file you need to edit to change the calendar.
   Add, edit, or delete the blocks between { } below, then save and upload.

   Each event looks like this:

   {
     date:     "2026-12-11",        <-- ALWAYS year-month-day, with dashes
     time:     "6:30 PM",           <-- when it starts (or "" if all day)
     callTime: "6:00 PM",           <-- when students should arrive ("" if none)
     title:    "Winter Concert",
     location: "School Gymnasium",
     grades:   ["3", "4", "5"],     <-- any of: K 1 2 3 4 5  (or ["All"])
     type:     "Concert",           <-- Concert, Rehearsal, Performance, Trip, Special Event
     required: true,                <-- true or false
     attire:   "Concert black",     <-- what to wear ("" if it doesn't matter)
     notes:    "Doors open at 6:15." <-- anything else ("" if nothing)
   },

   Keep the commas and quotation marks exactly where they are.
   The last item before the closing ]; does not need a trailing comma, but
   it is fine if it has one.
   ========================================================================== */

window.MF_EVENTS = [

  {
    date: "2026-10-09",
    time: "",
    callTime: "",
    title: "Recorder Karate begins",
    location: "Music Room",
    grades: ["3", "4"],
    type: "Special Event",
    required: false,
    attire: "",
    notes: "Students need their recorder in school every music day from this date on."
  },

  {
    date: "2026-10-23",
    time: "9:30 AM",
    callTime: "",
    title: "Fall Sing-Along Assembly",
    location: "School Gymnasium",
    grades: ["All"],
    type: "Performance",
    required: false,
    attire: "Regular school clothes",
    notes: "Families are welcome. Please sign in at the front office."
  },

  {
    date: "2026-12-03",
    time: "2:15 PM",
    callTime: "2:00 PM",
    title: "Winter Concert dress rehearsal",
    location: "School Gymnasium",
    grades: ["K", "1", "2", "3", "4", "5"],
    type: "Rehearsal",
    required: true,
    attire: "Regular school clothes",
    notes: "During the school day. No family attendance needed."
  },

  {
    date: "2026-12-10",
    time: "6:30 PM",
    callTime: "6:00 PM",
    title: "Winter Concert — Grades K, 1 & 2",
    location: "School Gymnasium",
    grades: ["K", "1", "2"],
    type: "Concert",
    required: true,
    attire: "Red or green top with dark pants or skirt",
    notes: "Students report to their classroom at call time. Doors open for families at 6:15 PM."
  },

  {
    date: "2026-12-11",
    time: "6:30 PM",
    callTime: "6:00 PM",
    title: "Winter Concert — Grades 3, 4 & 5",
    location: "School Gymnasium",
    grades: ["3", "4", "5"],
    type: "Concert",
    required: true,
    attire: "Red or green top with dark pants or skirt",
    notes: "Students report to their classroom at call time. Doors open for families at 6:15 PM."
  },

  {
    date: "2027-02-12",
    time: "9:30 AM",
    callTime: "",
    title: "Black History Month Program",
    location: "School Gymnasium",
    grades: ["All"],
    type: "Performance",
    required: false,
    attire: "Regular school clothes",
    notes: ""
  },

  {
    date: "2027-03-19",
    time: "8:00 AM",
    callTime: "7:45 AM",
    title: "Field trip — South Bend Symphony Young People's Concert",
    location: "Morris Performing Arts Center",
    grades: ["4", "5"],
    type: "Trip",
    required: false,
    attire: "School spirit shirt",
    notes: "Permission slips are due two weeks before. Students are back in time for lunch."
  },

  {
    date: "2027-04-22",
    time: "3:15 PM",
    callTime: "3:10 PM",
    title: "Spring Concert rehearsal",
    location: "School Gymnasium",
    grades: ["All"],
    type: "Rehearsal",
    required: true,
    attire: "",
    notes: "After school. Pick up at 4:15 PM at the gym doors."
  },

  {
    date: "2027-05-06",
    time: "6:30 PM",
    callTime: "6:00 PM",
    title: "Spring Concert",
    location: "School Gymnasium",
    grades: ["All"],
    type: "Concert",
    required: true,
    attire: "Concert best — no jeans or sneakers if possible",
    notes: "Our biggest night of the year. Every grade performs."
  }

];
