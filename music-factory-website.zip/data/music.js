/* ==========================================================================
   THE MUSIC FACTORY — PRACTICE MATERIALS BY GRADE
   --------------------------------------------------------------------------
   This is the ONLY file you need to edit to change the Music page.

   Each grade is one "module". Inside a module you list songs, and inside
   each song you list the links students need.

   A link ("resource") looks like this:

     { kind: "lyrics", label: "Lyrics sheet", url: "https://..." }

   kind can be any of:
     lyrics         (words to the song)
     recording      (full recording to sing along with)
     track          (accompaniment / karaoke track)
     choreography   (dance video or motions)
     video          (any other video)
     pdf            (sheet music or a handout)
     link           (anything else)

   The url can be a Google Drive link, a YouTube link, a SoundCloud link,
   a file you uploaded to the site, or anything else that opens in a browser.
   Make sure Google Drive links are set to "Anyone with the link can view."

   To hide a grade for now, give it an empty songs list:  songs: []
   ========================================================================== */

window.MF_MUSIC = [

  {
    id: "kindergarten",
    badge: "K",
    color: "var(--red)",
    title: "Kindergarten",
    subtitle: "Steady beat, singing voice, and our first performance songs",
    intro: "Kindergarten friends are learning to find their singing voice and keep a steady beat. Ten minutes of singing along at home makes a big difference.",
    songs: [
      {
        title: "Hello, How Are You?",
        forEvent: "Warm-up we use every class",
        resources: [
          { kind: "recording", label: "Sing-along recording", url: "#" },
          { kind: "lyrics", label: "Lyrics sheet", url: "#" }
        ]
      },
      {
        title: "Snowflakes Falling Down",
        forEvent: "Winter Concert",
        resources: [
          { kind: "recording", label: "Sing-along recording", url: "#" },
          { kind: "track", label: "Accompaniment track", url: "#" },
          { kind: "lyrics", label: "Lyrics sheet", url: "#" },
          { kind: "choreography", label: "Motions video", url: "#" }
        ]
      }
    ]
  },

  {
    id: "grade-1",
    badge: "1",
    color: "var(--orange-deep)",
    title: "First Grade",
    subtitle: "High and low, loud and soft, and lots of singing games",
    intro: "First graders are working on matching pitch and following the beat. Encourage your student to sing along with the recordings rather than just listening.",
    songs: [
      {
        title: "Mister Sun",
        forEvent: "Class singing",
        resources: [
          { kind: "recording", label: "Sing-along recording", url: "#" },
          { kind: "lyrics", label: "Lyrics sheet", url: "#" }
        ]
      },
      {
        title: "The Gingerbread Man",
        forEvent: "Winter Concert",
        resources: [
          { kind: "recording", label: "Sing-along recording", url: "#" },
          { kind: "track", label: "Accompaniment track", url: "#" },
          { kind: "lyrics", label: "Lyrics sheet", url: "#" },
          { kind: "choreography", label: "Motions video", url: "#" }
        ]
      }
    ]
  },

  {
    id: "grade-2",
    badge: "2",
    color: "var(--green-deep)",
    title: "Second Grade",
    subtitle: "Rhythm reading, classroom instruments, and two-part songs",
    intro: "Second graders are starting to read rhythms and play along on classroom instruments. Practicing the words first makes the playing part much easier.",
    songs: [
      {
        title: "Four White Horses",
        forEvent: "Class singing game",
        resources: [
          { kind: "recording", label: "Sing-along recording", url: "#" },
          { kind: "lyrics", label: "Lyrics sheet", url: "#" }
        ]
      },
      {
        title: "Winter Wonderland Medley",
        forEvent: "Winter Concert",
        resources: [
          { kind: "recording", label: "Sing-along recording", url: "#" },
          { kind: "track", label: "Accompaniment track", url: "#" },
          { kind: "lyrics", label: "Lyrics sheet", url: "#" }
        ]
      }
    ]
  },

  {
    id: "grade-3",
    badge: "3",
    color: "var(--blue)",
    title: "Third Grade",
    subtitle: "Recorder Karate, note reading, and part-singing",
    intro: "Third graders begin recorder this year. Recorders should come home in the case every night and go back to school every music day. Five minutes of practice a day beats an hour on the weekend.",
    songs: [
      {
        title: "Recorder Karate — White Belt: Hot Cross Buns",
        forEvent: "Recorder Karate",
        resources: [
          { kind: "pdf", label: "Music (PDF)", url: "#" },
          { kind: "video", label: "Play-along video", url: "#" },
          { kind: "track", label: "Slow practice track", url: "#" }
        ]
      },
      {
        title: "Recorder Karate — Yellow Belt: Gently Sleep",
        forEvent: "Recorder Karate",
        resources: [
          { kind: "pdf", label: "Music (PDF)", url: "#" },
          { kind: "video", label: "Play-along video", url: "#" }
        ]
      },
      {
        title: "Light the Candles",
        forEvent: "Winter Concert",
        resources: [
          { kind: "recording", label: "Sing-along recording", url: "#" },
          { kind: "track", label: "Accompaniment track", url: "#" },
          { kind: "lyrics", label: "Lyrics sheet", url: "#" }
        ]
      }
    ]
  },

  {
    id: "grade-4",
    badge: "4",
    color: "var(--purple)",
    title: "Fourth Grade",
    subtitle: "Two-part harmony, recorder, and reading standard notation",
    intro: "Fourth graders are singing in two parts this year. Each concert song has a Part 1 and Part 2 track so students can practice their own line at home.",
    songs: [
      {
        title: "Sing a Song of Peace",
        forEvent: "Winter Concert",
        resources: [
          { kind: "recording", label: "Full recording", url: "#" },
          { kind: "track", label: "Part 1 practice track", url: "#" },
          { kind: "track", label: "Part 2 practice track", url: "#" },
          { kind: "lyrics", label: "Lyrics sheet", url: "#" }
        ]
      },
      {
        title: "This Little Light of Mine",
        forEvent: "Black History Month Program",
        resources: [
          { kind: "recording", label: "Full recording", url: "#" },
          { kind: "track", label: "Accompaniment track", url: "#" },
          { kind: "lyrics", label: "Lyrics sheet", url: "#" }
        ]
      }
    ]
  },

  {
    id: "grade-5",
    badge: "5",
    color: "var(--teal)",
    title: "Fifth Grade",
    subtitle: "Harmony, solos, and getting ready for middle school music",
    intro: "Fifth graders take on the hardest music in the building and lead our spring program. Students auditioning for solos should practice with the accompaniment track, not just the full recording.",
    songs: [
      {
        title: "Seasons of Love",
        forEvent: "Spring Concert",
        resources: [
          { kind: "recording", label: "Full recording", url: "#" },
          { kind: "track", label: "Accompaniment track", url: "#" },
          { kind: "lyrics", label: "Lyrics sheet", url: "#" },
          { kind: "choreography", label: "Staging video", url: "#" }
        ]
      },
      {
        title: "Fifth Grade Farewell",
        forEvent: "Spring Concert finale",
        resources: [
          { kind: "recording", label: "Full recording", url: "#" },
          { kind: "track", label: "Accompaniment track", url: "#" },
          { kind: "lyrics", label: "Lyrics sheet", url: "#" }
        ]
      }
    ]
  },

  {
    id: "all-school",
    badge: "ALL",
    color: "var(--navy)",
    title: "All-School Songs",
    subtitle: "Everybody sings these — every grade, every year",
    intro: "These are the songs the whole school sings together at assemblies and at the end of every concert. Students of every age can practice these at home.",
    songs: [
      {
        title: "The Star-Spangled Banner",
        forEvent: "Every concert",
        resources: [
          { kind: "recording", label: "Sing-along recording", url: "#" },
          { kind: "lyrics", label: "Lyrics sheet", url: "#" }
        ]
      },
      {
        title: "Our School Song",
        forEvent: "Assemblies",
        resources: [
          { kind: "recording", label: "Sing-along recording", url: "#" },
          { kind: "lyrics", label: "Lyrics sheet", url: "#" }
        ]
      }
    ]
  }

];
