# The Music Factory — website

A four-page website for our school music program: **Home**, **Calendar**, **Music & Practice**, and **Contact**.

It is a plain static site — HTML, CSS, and a little JavaScript. There is nothing to install, no build step, and no database. That means it is fast, free to host, and hard to break.

---

## What's in here

```
index.html          Home page (welcome, quick links, next 3 events)
calendar.html       Full calendar, filterable by grade and event type
music.html          Practice materials, one module per grade level
contact.html        Miss Bathurst's contact info + family FAQ
404.html            Shown if someone follows a broken link

data/events.js      ← EDIT THIS to change the calendar
data/music.js       ← EDIT THIS to change the practice materials

assets/css/styles.css   All the styling (colors are at the very top)
assets/js/main.js       Site behavior — you shouldn't need to touch this
assets/img/             Logo and favicon

_headers            Cloudflare security + caching settings
robots.txt          Lets search engines list the site
```

**The important idea:** all the content you'll change day to day lives in the two files in the `data/` folder. You never have to edit HTML to add a concert or post a new song.

---

## Part 1 — Put it on GitHub

You only do this once.

1. Go to [github.com](https://github.com) and sign in (create a free account if you don't have one).
2. Click the **+** in the top right → **New repository**.
3. Name it `music-factory`. Leave it **Public**. Don't add a README (you already have one). Click **Create repository**.
4. On the next screen, click **uploading an existing file**.
5. Drag the *contents* of this folder into the browser window — all the `.html` files plus the `assets` and `data` folders. Make sure you upload the folders themselves, not just the files inside them.
6. Scroll down and click **Commit changes**.

Your files are now on GitHub. You can stop here if you just want a backup, or keep going to put it on the web.

---

## Part 2 — Publish with Cloudflare Pages

Also a one-time setup. It's free.

1. Go to [dash.cloudflare.com](https://dash.cloudflare.com) and sign in (free account).
2. In the left sidebar choose **Compute (Workers & Pages)** → **Create** → **Pages** tab → **Connect to Git**.
3. Authorize Cloudflare to see your GitHub account, then pick the `music-factory` repository.
4. On the build settings screen:
   - **Framework preset:** `None`
   - **Build command:** leave it **empty**
   - **Build output directory:** `/`
5. Click **Save and Deploy**.

After about a minute you'll get a web address like `music-factory.pages.dev`. That's your live site — share it with families.

> Cloudflare's menu names change from time to time. If a label doesn't match exactly, look for "Pages" and "Connect to Git" — that's the path.

### Updating the live site later

Every time you change a file on GitHub and commit it, Cloudflare rebuilds and republishes automatically within a minute or two. You do not go back to Cloudflare.

### Using a nicer web address

If the district gives you something like `music.yourschool.org`, add it in Cloudflare under your Pages project → **Custom domains**. The district's tech office has to add one DNS record; Cloudflare shows you exactly which one. Check with them before promising families a custom address — some districts require program pages to live on the official district site instead.

---

## Part 3 — Adding a concert or event

1. On GitHub, open the `data` folder and click **events.js**.
2. Click the pencil ✏️ icon to edit.
3. Copy an existing block (everything from `{` to `},`) and paste it where you want it.
4. Change the details. The fields are:

| Field | What it is | Example |
|---|---|---|
| `date` | Year-month-day, with dashes, always four-digit year | `"2026-12-10"` |
| `time` | When it starts for families | `"6:30 PM"` |
| `callTime` | When students need to arrive | `"6:00 PM"` |
| `title` | Name of the event | `"Winter Concert"` |
| `location` | Where it is | `"School Gymnasium"` |
| `grades` | Who it's for | `["3", "4", "5"]` or `["All"]` |
| `type` | Concert, Rehearsal, Performance, Trip, or Special Event | `"Concert"` |
| `required` | `true` or `false` (no quotation marks) | `true` |
| `attire` | What to wear | `"Concert black"` |
| `notes` | Anything else | `"Doors open at 6:15."` |

5. Scroll down, click **Commit changes**.

That's it. The event shows up on the Calendar page and, if it's one of the next three, on the Home page too. Past events drop off the "Upcoming" view automatically — you never have to delete old ones.

**If something looks wrong after an edit,** it's almost always a missing comma or quotation mark. On GitHub, open the file's **History** and click **Revert** on your change to put it back the way it was.

---

## Part 4 — Adding music for a grade

1. Open `data/music.js` on GitHub and click the pencil ✏️.
2. Find the grade you want. Inside its `songs:` list, copy an existing song block and edit it.
3. Each link inside `resources` has three parts:
   - `kind` — one of `lyrics`, `recording`, `track`, `choreography`, `video`, `pdf`, `link`. This just picks the little icon.
   - `label` — what families see, e.g. `"Part 2 practice track"`
   - `url` — the web address the link opens
4. Commit changes.

### Where to put the actual audio and PDFs

Two easy options:

**Google Drive (recommended).** Upload the file to Drive, right-click → **Share** → change to **Anyone with the link** → **Viewer** → **Copy link**. Paste that link as the `url`. This keeps large audio files off the website and is easy to update.

**In the site itself.** Make a folder called `files` in the repository, upload PDFs there, and use a url like `"files/hot-cross-buns.pdf"`. Good for small PDFs; not great for big audio files.

**YouTube** links work as-is — just paste the normal video address.

A `url` of `"#"` is a placeholder that goes nowhere. The sample content ships with placeholders so you can see the layout; replace them with real links as you build the year.

### Turning a grade off for now

Give it an empty list — `songs: []` — and the module shows a friendly "coming soon" note instead.

---

## Part 5 — Before you share the link with families

- [ ] Replace every placeholder `"#"` link in `data/music.js` with a real one
- [ ] Check that Google Drive links are set to **Anyone with the link can view** (open one in a private browsing window to be sure)
- [ ] Replace the sample events in `data/events.js` with your real calendar
- [ ] Check the whole site on a phone — that's how most families will read it
- [ ] Have someone who isn't you click every link
- [ ] Confirm with the district office that a `.pages.dev` site is allowed, and whether they want the pages on the district site instead

---

## Accessibility notes

Public school websites fall under ADA Title II, which requires WCAG 2.1 Level AA. This site was built to meet that: it has a skip link, real heading structure, visible keyboard focus, labeled form controls, alt text on images, and color contrast that passes AA. Two things stay in your hands:

1. **Any PDF you link must itself be accessible** — real text, not a photo of a page. A scanned lyric sheet is not readable by a screen reader. When in doubt, put the words on the page as text.
2. **Videos should have captions.** YouTube's auto-captions are a starting point but should be corrected.

The footer includes a line inviting anyone who needs information in another format to contact you. Please honor those requests promptly — that's the part that actually matters.

---

## Student privacy

The site as delivered contains no student names or photos. Before adding any, check your district's FERPA directory-information policy and the opt-out list — some families have one. Safest practice: first names only, or no names at all, with group photos.

---

## Changing the colors

Open `assets/css/styles.css`. The first block, `:root { ... }`, holds every color on the site. Change a value there and it updates everywhere.

---

## Questions

Miss Bathurst · mbathurst@sbcsc.k12.in.us · (574) 393-3200 ext. 33244
